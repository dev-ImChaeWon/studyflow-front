<template>
  <h1>출석 요약</h1>
  <h1>최근 출석 현황</h1>
</template>