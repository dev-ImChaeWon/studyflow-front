<template>
    <NavBar/>
    <RouterView/>
    <PageFooter/>
</template>

<script setup>
import NavBar from '../NavBar.vue';
import PageFooter from '../PageFooter.vue';
</script>

<style scoped></style>