
<template>
  <router-view/>
</template>

<script setup>
</script>


<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+KR:wght@100;200;300;400;500;600;700&display=swap');
*{
  box-sizing: border-box;
  padding: 0;
  margin: 0;
  
  font-family: "IBM Plex Sans KR", sans-serif;
}

a{
  font-size: 12px;
  color: #7C8BA0;
  text-decoration: none;
}
</style>